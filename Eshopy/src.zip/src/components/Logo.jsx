import React from "react";
import PageNavigation from "./PageNavigation";
const Logo = () => {
  return (
    <>
      <div className="logo_agile">
        <h1>
          <span>E</span>lite Shoppy
        </h1>
      </div>
    </>
  );
};
export default Logo;
