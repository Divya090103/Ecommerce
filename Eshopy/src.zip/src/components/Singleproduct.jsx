import React, { useContext, useEffect } from "react";
import { useParams } from "react-router";
import { Appcontext } from "../context/Productcontext";
import PageNavigation from "./PageNavigation";
import { FaTruck } from "react-icons/fa";
import { TbReplace } from "react-icons/tb";
import { PiSealCheckFill } from "react-icons/pi";
import MyImage from "./MyImage";
import Rating from "./Rating";
import Color from "./AddCart";
import AddCart from "./AddCart";
const Singleproduct = () => {
  //get element from the url
  const { id } = useParams();
  const API = "http://localhost:3000/api/products";
  const { getsingleproduct, issingleload, singleproduct } =
    useContext(Appcontext);
  useEffect(() => {
    getsingleproduct(`${API}/?id=${id}`);
  }, []);
  console.log(`${API}/?id=${id}`);
  console.log("this is an id", id);
  console.log(singleproduct);
  const arr = singleproduct;
  console.log("colors", arr[0].colors);

  return (
    <>
      <section>
        <div className="container text- left mt-5">
          <div className="row">
            <div className="col-lg-6 col-md-12">
              {/* <MyImage myimage={arr.images} /> */}
            </div>
            <div className="col-lg-6 col-md-12">
              {/* <div>
                <h1>{singleproduct[0]?.name}</h1>
                <Rating
                  stars={singleproduct[0]?.stars}
                  review={singleproduct?.reviews}
                />
                <p className="text-secondary">
                  MRP:
                  <del>
                    {" "}
                    {new Intl.NumberFormat("en-IN", {
                      style: "currency",
                      currency: "INR",
                      maximumFractionDigits: 2,
                    }).format((singleproduct[0].price + 200000) / 10)}
                  </del>
                </p>
                <h5 className="text-primary">
                  Deal of the Day:
                  {new Intl.NumberFormat("en-IN", {
                    style: "currency",
                    currency: "INR",
                    maximumFractionDigits: 2,
                  }).format(singleproduct[0].price / 100)}
                </h5>
                <p className="text-secondary">{singleproduct?.description}</p>
              </div> */}
              <div className="d-flex align-items-center justify-content-between mt-4">
                <div className="text-center">
                  <TbReplace className="icon fs-2" />
                  <p>30 Days Replacement</p>
                </div>
                <div className="text-center">
                  <FaTruck className="icon fs-2" />
                  <p>Free Delivery</p>
                </div>
                <div className="text-center">
                  <PiSealCheckFill className="icon fs-2" />
                  <p>2year Warranty</p>
                </div>
                <div className="text-center">
                  <FaTruck className="icon fs-2" />
                  <p>Elitte Delivery</p>
                </div>
              </div>
              <hr />
              {/* <div>
                <h5>Available:In stock</h5>
                <h5>Brand:{singleproduct[0]?.company}</h5>
              </div> */}
              <hr />
            </div>
          </div>
        </div>
      </section>
    </>
  );
};
export default Singleproduct;
