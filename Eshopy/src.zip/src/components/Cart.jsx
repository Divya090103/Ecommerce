import React from "react";
const Cart=()=>{
  return(
    <h2>Cart page</h2>
    
  );
}
export default Cart;